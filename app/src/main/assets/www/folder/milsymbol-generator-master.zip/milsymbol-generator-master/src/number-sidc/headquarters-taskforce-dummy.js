export default function headquartersTaskforceDummy(symbolset) {
  if (symbolset == "10" || true) {
    return {
      0: {
        code: 0,
        index: 0,
        name: "Not Applicable",
        sidc: "10031000000000000000"
      },
      1: {
        code: 1,
        index: 1,
        name: "Feint/Dummy",
        sidc: "10031001000000000000"
      },
      2: {
        code: 2,
        index: 2,
        name: "Headquarters",
        sidc: "10031002000000000000"
      },
      3: {
        code: 3,
        index: 3,
        name: "Feint/Dummy Headquarters",
        sidc: "10031003000000000000"
      },
      4: {
        code: 4,
        index: 4,
        name: "Task Force",
        sidc: "10031004000000000000"
      },
      5: {
        code: 5,
        index: 5,
        name: "Feint/Dummy Task Force",
        sidc: "10031005000000000000"
      },
      6: {
        code: 6,
        index: 6,
        name: "Task Force Headquarters",
        sidc: "10031006000000000000"
      },
      7: {
        code: 7,
        index: 7,
        name: "Feint/Dummy Task Force Headquarters",
        sidc: "10031007000000000000"
      }
    };
  }

  return {};
}
